# PostgreSQL & pgAdmin Docker Setup for TCS QE Migration Studio

This directory contains the Docker configuration to run a local PostgreSQL 16 database and pgAdmin 4 for TCS QE Migration Studio.

## Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running.

## Starting the Database
From this directory, run:
```bash
docker compose up -d
```

## Database Details
- **Host**: `localhost`
- **Port**: `5432`
- **User**: `qe_user`
- **Password**: `qe_password_secret`
- **Database**: `qe_studio`
- **Connection URI**: `postgresql://qe_user:qe_password_secret@localhost:5432/qe_studio`

## pgAdmin Web Interface
- **URL**: [http://localhost:5050](http://localhost:5050)
- **Login**: `admin@qestudio.ai`
- **Password**: `admin1234`
