# TCS QE Migration Studio
### Production-Grade AI-Powered Quality Engineering Platform for Enterprise Integration & API Migration

---

## 🌟 Executive Overview
**TCS QE Migration Studio** is a modular, AI-powered Quality Engineering platform engineered for enterprise API and integration migration projects (such as cutovers from legacy SOAP/REST services to **Workato** recipes and cloud microservices).

Rather than serving as a static dashboard, TCS QE Migration Studio provides a functional, stateful, agentic environment featuring:
- **BRD / Spec Ingestion**: Ingests PDF, DOCX, Markdown, and TXT specifications with LangChain document loaders, extracting requirement sections and migration parameters.
- **Agentic Manual Test Case Generation**: Multi-step **LangGraph** workflows synthesize comprehensive manual test cases (Migration Parity, Functional, Boundary Edge Cases, Error Handling, and Security) with inline refinement and multi-format export (CSV, Markdown, JSON).
- **Synthetic Test Data Generation**: Schema-aware synthetic data generator that injects boundary values, max-length fields, unicode characters, and negative test records.
- **Playwright Automation Synthesis & Runner**: Generates ready-to-run Playwright tests in both **TypeScript** (`@playwright/test`) and **Python** (`pytest-playwright`), with local headless execution diagnostics and assertion reports.
- **Workato Migration Testing Hub**: Dual-mode Workato platform integration (Live REST API + high-fidelity simulation engine). An AI validation agent formulates test payloads, triggers recipes, analyzes multi-step job logs, and produces verified migration parity reports.
- **FinOps & Token Telemetry**: Tracks token consumption (prompt, completion, total), model inference costs (USD), and latency for every agent invocation, visualized through an interactive Recharts dashboard.
- **Dynamic LLM Switcher**: Switch models (`gpt-4o`, `gpt-4o-mini`, `gpt-4-turbo`, `gpt-35-turbo`) and providers (Azure OpenAI Foundry or Direct OpenAI) on the fly via the Studio Settings page.

---

## 🏗️ Architecture & Tech Stack

```mermaid
graph TD
    Client["Next.js 16+ Frontend (App Router, TypeScript, Tailwind CSS, Recharts)"]
    API["FastAPI Backend (Python 3.11, Pydantic v2, CORS, Alembic)"]
    DB[("PostgreSQL 16 in Docker (with auto SQLite fallback)")]
    Azure["Azure OpenAI Foundry (gpt-4o) / Dynamic LLM Switcher"]
    Workato["Workato iPaaS REST API / Migration Sandbox Simulator"]
    Playwright["Playwright Headless Test Runner (TypeScript / Python)"]
    LangGraph["LangGraph Stateful Multi-step Agent Orchestration"]

    Client -->|REST API| API
    API --> DB
    API --> LangGraph
    LangGraph --> Azure
    API --> Workato
    API --> Playwright
```

---

## 📋 System Prerequisites

Ensure the following runtimes and tools are installed on your workstation:

| Prerequisite | Minimum Version | Recommended | Notes |
| :--- | :--- | :--- | :--- |
| **Python** | `3.11+` | `3.11.9` | Ensure `python` and `pip` are added to system `PATH` |
| **Node.js** | `18.18+` | `20.x` or `22.x` | Includes `npm` (v10+) |
| **Docker & Docker Compose** | Latest | Docker Desktop | *Optional* – system automatically falls back to local SQLite if Docker is offline |

---

## 🚀 Initial Setup Guide (First-Time Setup)

Follow these steps sequentially to set up and run TCS QE Migration Studio on a new machine.

### Step 1: Database Setup (PostgreSQL or SQLite)

TCS QE Migration Studio includes a plug-and-play Docker Compose configuration for PostgreSQL 16 and pgAdmin 4.

> **💡 Zero-Docker Fallback:** If Docker is not running or not installed, **skip this step**. The backend will automatically detect the absence of PostgreSQL and create a local SQLite database (`qe_studio.db`) without any configuration changes.

If using Docker:
```powershell
# Navigate to Docker directory and start containers in the background
cd "c:\GEN AI\QE STUDIO\postgress docker"
docker compose up -d
```
- **PostgreSQL Port:** `5432` (User: `qe_user`, DB: `qe_studio`)
- **pgAdmin 4 Web Console:** [http://localhost:5050](http://localhost:5050) (Login: `admin@qestudio.ai` / `admin1234`)

---

### Step 2: Backend Setup (FastAPI & LangGraph)

1. **Navigate to the backend directory:**
   ```powershell
   cd "c:\GEN AI\QE STUDIO\backend"
   ```

2. **(Recommended) Create and activate a Python virtual environment:**
   ```powershell
   # Create virtual environment
   python -m venv venv

   # Activate on Windows PowerShell:
   .\venv\Scripts\Activate.ps1
   # (If script execution is disabled, run: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass)

   # Activate on macOS/Linux:
   # source venv/bin/activate
   ```

3. **Install Python dependencies:**
   ```powershell
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. **Install Playwright headless browser binaries:**
   *(Required for the Playwright automation execution engine)*
   ```powershell
   playwright install chromium
   ```

5. **Configure Environment Variables:**
   A template file `.env.example` is available. Verify or edit `.env`:
   ```powershell
   # If .env does not exist, copy from .env.example
   Copy-Item .env.example .env
   ```
   Key variables in `backend/.env`:
   ```dotenv
   # Azure OpenAI Configuration
   AZURE_OPENAI_API_KEY=your_key_here
   AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
   AZURE_OPENAI_API_VERSION=2024-08-01-preview

   # Database Configuration
   DATABASE_URL=postgresql://qe_user:qe_password_secret@localhost:5432/qe_studio
   FALLBACK_SQLITE_URL=sqlite:///./qe_studio.db

   # Workato Configuration
   WORKATO_API_URL=https://www.workato.com/api
   WORKATO_MOCK_MODE=true

   # Server Configuration
   PORT=8000
   CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
   ```

6. **Start the FastAPI Backend:**
   ```powershell
   python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
   ```
   - Swagger Interactive Documentation: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
   - ReDoc Documentation: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)
   - Health Probe: [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health)

---

### Step 3: Frontend Setup (Next.js 16 + React 19)

1. **Open a new terminal window** and navigate to the frontend directory:
   ```powershell
   cd "c:\GEN AI\QE STUDIO\frontend"
   ```

2. **Install Node.js dependencies:**
   ```powershell
   npm install
   ```

3. **(Optional) Configure environment:**
   By default, the frontend automatically routes API requests to `http://127.0.0.1:8000/api`. If you need custom endpoints, create `.env.local`:
   ```powershell
   Copy-Item .env.example .env.local
   ```

4. **Start the Next.js development server:**
   ```powershell
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## ⚡ Daily Development Command Cheat Sheet

Use this reference table for everyday operations:

### 🚀 Starting Services

| Action | Command (PowerShell / Windows) | Command (Bash / macOS / Linux) | Directory |
| :--- | :--- | :--- | :--- |
| **Start Docker DB** | `docker compose up -d` | `docker compose up -d` | `postgress docker/` |
| **Start Backend** | `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload` | `uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload` | `backend/` |
| **Start Frontend** | `npm run dev` | `npm run dev` | `frontend/` |

---

### 🔍 Health & Status Checks

| Target | PowerShell / Shell Command | Expected Response / Indicator |
| :--- | :--- | :--- |
| **Backend Health** | `curl http://127.0.0.1:8000/health` | `{"status":"healthy","service":"TCS QE Migration Studio",...}` |
| **Frontend UI** | `curl -I http://localhost:3000` | `HTTP/1.1 200 OK` |
| **Check Port 8000** | `Test-NetConnection -ComputerName 127.0.0.1 -Port 8000` | `TcpTestSucceeded : True` |
| **Check Port 3000** | `Test-NetConnection -ComputerName 127.0.0.1 -Port 3000` | `TcpTestSucceeded : True` |
| **Docker Containers** | `docker ps` | `qe_studio_postgres`, `qe_studio_pgadmin` running |
| **Find Listening Ports** | `Get-NetTCPConnection -State Listen \| Where-Object { $_.LocalPort -in 3000, 8000, 5432 }` | Shows Active Process IDs |

---

### 🛑 Stopping Services

| Action | PowerShell Command | Bash / Linux Command |
| :--- | :--- | :--- |
| **Stop Running Terminal** | `Ctrl + C` | `Ctrl + C` |
| **Stop Docker Services** | `docker compose down` | `docker compose down` |
| **Kill Port 8000 Process** | `Stop-Process -Id (Get-NetTCPConnection -LocalPort 8000).OwningProcess -Force` | `kill $(lsof -t -i:8000)` |
| **Kill Port 3000 Process** | `Stop-Process -Id (Get-NetTCPConnection -LocalPort 3000).OwningProcess -Force` | `kill $(lsof -t -i:3000)` |

---

## 🌐 Application Endpoints & Ports

| Component | Default URL | Description |
| :--- | :--- | :--- |
| **TCS QE Migration Studio Web Dashboard** | [http://localhost:3000](http://localhost:3000) | Main user interface (Next.js App Router) |
| **Backend API Root** | [http://127.0.0.1:8000](http://127.0.0.1:8000) | FastAPI core engine |
| **Interactive API Docs (Swagger)**| [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) | Test backend API endpoints interactively |
| **Backend Health Check** | [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health) | Real-time health, LLM provider, and model status |
| **PostgreSQL Database** | `localhost:5432` | Relational test results, telemetry, and project store |
| **pgAdmin 4 Dashboard** | [http://localhost:5050](http://localhost:5050) | PostgreSQL graphical administration interface |

---

## 🧪 Modules & Features

| Module | Route | Key Capabilities |
| :--- | :--- | :--- |
| **Executive Dashboard** | `/` | Migration health metrics, automation readiness %, parity rate, FinOps spend ticker. |
| **BRD / Spec Ingestion** | `/brd-spec` | Ingests PDF/DOCX/MD specs, requirement section extraction, pre-loaded enterprise migration samples. |
| **Manual Test Cases** | `/test-cases` | LangGraph agent generation, prompt fine-tuning bar, inline editing, CSV/JSON/MD export. |
| **Synthetic Test Data** | `/test-data` | Schema-aware synthesis, row count slider, boundary/unicode edge case injection, CSV/JSON downloads. |
| **Playwright Automation** | `/playwright` | Dual TypeScript/Python generator, code viewer, headless test runner with real-time assertions. |
| **Workato Migration** | `/workato` | Recipe trigger strategist, live & simulation dual-mode, step-by-step log analyzer, AI migration verdict. |
| **AI Payload Reconciler** | `/reconciliation` | Real-time semantic response diffing, field discrepancy classification, remediation suggestions. |
| **Tosca & qTest Hub** | `/integrations` | Model-Based Test Automation (MBTA) module synthesis, Tosca DEX execution dispatcher, qTest bi-directional sync. |
| **FinOps & Tokens** | `/finops` | Real-time token consumption, cost breakdown by workflow, model cost comparison, latency telemetry. |
| **Settings & Models** | `/settings` | Switch active LLMs, Azure endpoint config, Workato credentials, Tosca DEX/TDS endpoints, and qTest configuration. |

---

## 🔗 Enterprise Test Ecosystem: Tricentis Tosca & qTest Integration (RFP Ready)

TCS QE Migration Studio acts as an intelligent cognitive orchestration layer above existing enterprise test suites, integrating directly with **Tricentis Tosca** (Model-Based Test Automation & DEX) and **Tricentis qTest** (Agile Test Management):

### 1. Tricentis Tosca Integration
- **Model-Based Automation (MBTA) Synthesis**: Rather than generating static code, the studio converts BRD requirements and API migration vectors into **Tosca API Scan Modules** and **TestCase subsets** (`.json` / standard Tosca import format) with defined technical attributes and ActionModes (`Input`, `Verify`, `Buffer`).
- **Distributed Execution (DEX) Dispatcher**: Connects to the Tosca Commander REST API / DEX Server to trigger remote ExecutionLists across distributed agents (e.g. `AGENT-AZURE-WIN11-DEX01`) and ingest step-by-step assertion results into the studio ledger.
- **Test Data Service (TDS) Streaming**: Directly provisions GenAI synthetic boundary records into Tosca TDS repositories for stateful test consumption.

### 2. Tricentis qTest Manager Integration
- **Bi-directional Test Case Sync**: Automatically maps generated migration test cases into designated qTest Modules (`/api/v3/projects/{projectId}/test-cases`) with full step-by-step verification points and preconditions.
- **Automated Test Cycle Formulation**: Generates release-specific Test Cycles in qTest Pulse for continuous cutover validation and executive reporting.
- **Traceability to Jira**: Maintains bidirectional links between client Business Requirement Documents, Jira User Stories, and qTest execution runs.

---

## 🛠️ Troubleshooting & FAQ

### 1. `Cannot connect to PostgreSQL` warning in Backend console
- **Symptom:** Backend logs indicate `Could not connect to PostgreSQL... Falling back to local SQLite database`.
- **Resolution:** This is completely normal if Docker is offline. The app automatically initializes `qe_studio.db` SQLite database with full feature parity. If you want PostgreSQL, start Docker Desktop and run `docker compose up -d` in the `postgress docker` folder.

### 2. PowerShell script execution policy error (`running scripts is disabled`)
- **Symptom:** Running `.\venv\Scripts\Activate.ps1` produces `File ... cannot be loaded because running scripts is disabled on this system`.
- **Resolution:** Run the following in your PowerShell session:
  ```powershell
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  ```
  Then re-run `.\venv\Scripts\Activate.ps1`.

### 3. Port `8000` or `3000` is already in use
- **Symptom:** `[Errno 10048] error while attempting to bind on address ('0.0.0.0', 8000)`.
- **Resolution:** Find and terminate the process holding the port:
  ```powershell
  Get-Process -Id (Get-NetTCPConnection -LocalPort 8000).OwningProcess | Stop-Process -Force
  ```

### 4. Playwright Headless Browser Not Found
- **Symptom:** `playwright._impl._errors.Error: Executable doesn't exist at ...`
- **Resolution:** Run `playwright install chromium` inside your active Python environment.

---

## 🔒 Security Best Practices
- Never commit active `.env` files with production API keys to source control.
- Use `.env.example` as the source of truth for repository variable templates.
- Production deployments should set `CORS_ORIGINS` to explicit domain origins rather than wildcards.
