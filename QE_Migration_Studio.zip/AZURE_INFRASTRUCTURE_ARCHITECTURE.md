# Microsoft Azure Deployment & Infrastructure Architecture Specification
## **Enterprise AI-Driven TCS QE Migration Studio**

> **Document Type:** Enterprise Architecture & RFP Response Technical Annex  
> **Target Audience:** Client Enterprise Architects, Cloud Engineering, InfoSec & Procurement Committees  
> **Platform Version:** Enterprise v2.4  
> **Deployment Target:** Microsoft Azure (Commercial / Government / Sovereign Cloud)  

---

## 1. Executive Summary

**TCS QE Migration Studio** is a cloud-native, enterprise-grade Quality Engineering platform that harnesses multi-step agentic LLM workflows (LangGraph) to automate the end-to-end quality lifecycle. It autonomously parses complex Business Requirement Documents (BRDs), synthesizes rigorous test case suites, generates runnable Playwright automation code, validates iPaaS/Workato recipe integrations, and synthesizes schema-aware boundary test datasets.

This document articulates the complete **Microsoft Azure Infrastructure Specification** required to host, secure, scale, and operate TCS QE Migration Studio in a client-owned Azure Subscription or Managed Service Environment.

---

## 2. End-to-End System Architecture

The solution utilizes a decoupled, zero-trust cloud architecture adhering to the **Microsoft Azure Well-Architected Framework** across Security, Reliability, Performance Efficiency, and Cost Optimization.

```mermaid
graph TD
    subgraph Users ["Corporate Enterprise Network"]
        Browser["QA Engineers / Leads / Auditors"]
        CI_CD["Azure DevOps / GitHub Actions Pipelines"]
    end

    subgraph Edge ["Perimeter & Edge Tier"]
        DNS["Azure DNS (Private/Public Zone)"]
        WAF["Azure Application Gateway v2 (WAF Mode)"]
        Entra["Microsoft Entra ID (SSO / OIDC / MFA)"]
    end

    subgraph VNet ["Azure Virtual Network (VNet: 10.240.0.0/16)"]
        subgraph AppSubnet ["App Subnet (10.240.1.0/24) - Delegated to ACA"]
            FE["Frontend Container App (Next.js 16)
Port: 3000 | 1 vCPU, 2GB RAM"]
            BE["Backend API & Agent Orchestrator (FastAPI / LangGraph)
Port: 8000 | 2 vCPU, 4GB RAM"]
            PW["Playwright Headless Execution Runner
/dev/shm >= 2GB | Chromium / WebKit"]
        end

        subgraph DBSubnet ["Database Subnet (10.240.2.0/24) - Delegated"]
            PG[("Azure Database for PostgreSQL Flexible Server
Standard_D4ds_v5 | Zone-Redundant HA")]
        end

        subgraph PrivateLinkSubnet ["Private Link Subnet (10.240.3.0/24)"]
            PE_AI["Private Endpoint: Azure OpenAI / AI Foundry"]
            PE_KV["Private Endpoint: Azure Key Vault"]
            PE_BLOB["Private Endpoint: Azure Blob Storage"]
        end
    end

    subgraph ManagedServices ["Azure PaaS & AI Services (Private Link Connected)"]
        AOAI["Azure OpenAI Service / AI Foundry
(gpt-4o, gpt-4.1-mini, gpt-4.1-nano)"]
        KV["Azure Key Vault
(Secrets & Certificates)"]
        BLOB["Azure Blob Storage
(BRD Docs, Playwright ZIPs, Test Data)"]
        ACR["Azure Container Registry
(Private Vulnerability-Scanned Images)"]
        MON["Azure Monitor & Log Analytics
(FinOps & Application Insights)"]
    end

    Browser -->|HTTPS 443| DNS
    DNS --> WAF
    CI_CD -->|REST API / Webhooks| WAF
    WAF -.->|SAML 2.0 / OIDC| Entra
    WAF -->|Internal TLS| FE
    WAF -->|Internal /api/*| BE
    FE -->|REST API Call| BE
    BE -->|PostgreSQL Port 5432| PG
    BE -->|Job Execution| PW
    BE -->|Private Link TLS 1.3| PE_AI --> AOAI
    BE -->|Managed Identity| PE_KV --> KV
    BE -->|Blob Storage API| PE_BLOB --> BLOB
    AppSubnet -.->|Pulls Images| ACR
    BE -.->|Telemetry & Tokens| MON
```

---

## 3. Data Flow & Agentic Execution Lifecycle

The following sequence illustrates the flow of data from BRD ingestion to test case generation, Playwright code synthesis, test data creation, and persistent scenario export:

```mermaid
sequenceDiagram
    autonumber
    actor User as QE Lead / Tester
    participant UI as Next.js 16 Frontend
    participant API as FastAPI Orchestrator
    participant Graph as LangGraph Multi-Agent
    participant LLM as Azure OpenAI (gpt-4o)
    participant DB as PostgreSQL Flexible Server
    participant Blob as Azure Blob Storage

    User->>UI: Select/Create Scenario & Upload BRD (.pdf / .docx)
    UI->>API: POST /api/documents/upload (project_id=SCEN-01)
    API->>Blob: Store raw document
    API->>DB: Record document metadata & raw text
    API-->>UI: Upload verified (Doc ID: 101)

    User->>UI: Trigger "Generate Test Cases"
    UI->>API: POST /api/test-cases/generate
    API->>Graph: Invoke LangGraph (extract_features -> generate_test_cases)
    Graph->>LLM: Semantic analysis & test case extraction
    LLM-->>Graph: Structured test cases JSON
    Graph-->>API: Test suite payload
    API->>DB: Persist isolated test cases (project_id=SCEN-01)
    API-->>UI: Display generated test cases suite

    User->>UI: Fine-tune test case via GenAI prompt
    UI->>API: POST /api/test-cases/{id}/refine (Prompt)
    API->>LLM: Refine test case fields & negative assertions
    LLM-->>API: Updated test case JSON
    API->>DB: Update TestCase record
    API-->>UI: Real-time updated test case card

    User->>UI: Generate Playwright Suite & Download ZIP
    UI->>API: POST /api/automation/generate-all
    API->>LLM: Synthesize TypeScript/Python Playwright specs
    API->>DB: Persist automation scripts
    UI->>API: GET /api/automation/export-zip?project_id=SCEN-01
    API-->>UI: Stream playwright_suite_scen_01.zip (Specs, Config, package.json)

    User->>UI: Synthesize Test Data for Scenario & Download ZIP
    UI->>API: POST /api/test-data/generate-for-scenario
    API->>LLM: Generate schema boundary records for all test cases
    API->>DB: Store test datasets (test_datasets table)
    UI->>API: GET /api/test-data/export-zip?project_id=SCEN-01
    API-->>UI: Stream test_data_scen_01.zip (JSON, CSV, manifest.json)
```

---

## 4. Azure Bill of Materials (BoM) & Infrastructure Sizing

Depending on the scale of the client organization, three standardized sizing profiles are available:

### Infrastructure Sizing Profiles

| Component | Profile A: Pilot / PoC | Profile B: Enterprise Standard *(Recommended)* | Profile C: High-Throughput Enterprise |
| :--- | :--- | :--- | :--- |
| **Concurrent Users** | 10 – 25 users | 50 – 300 users | 500+ users |
| **Daily Test Executions**| 50 – 100 runs/day | 500 – 2,000 runs/day | 5,000+ runs/day |
| **Frontend Compute** | 1 Replica (1 vCPU, 2GB RAM) | 2 Replicas (1 vCPU, 2GB RAM each) | 3 – 5 Replicas (Autoscaling) |
| **Backend Compute** | 1 Replica (2 vCPU, 4GB RAM) | 3 Replicas (2 vCPU, 4GB RAM each) | 4 – 10 Replicas (Autoscaling) |
| **Database (PostgreSQL)**| Standard_B2s (2 vCPU, 4GB RAM) | **Standard_D4ds_v5** (4 vCPU, 16GB RAM) | Standard_D8ds_v5 (8 vCPU, 32GB RAM) |
| **DB High Availability**| Single Node | **Zone-Redundant HA** with Standby | **Zone-Redundant HA + Read Replica** |
| **DB Storage & IOPS** | 64 GB SSD (Auto-grow) | 256 GB SSD (Up to 3,000 IOPS) | 512 GB SSD (Up to 6,000 IOPS) |
| **Azure OpenAI Quota** | 50,000 TPM | **100,000 – 200,000 TPM** | 300,000+ TPM (or PTU) |
| **Object Storage** | 100 GB Standard LRS | 1 TB Standard ZRS | 5 TB Standard GRS |
| **WAF / Ingress** | Azure App Gateway Standard v2 | **Azure App Gateway WAF_v2** | Azure Front Door + App Gateway WAF |

---

## 5. Component Technical Specifications

### 5.1 Application Compute: Azure Container Apps (ACA)
The solution is deployed within an **Azure Container Apps Managed Environment** configured with internal VNet delegation:

* **Container Packaging**:
  * **Frontend**: Node.js 20 Alpine optimized multi-stage build.
  * **Backend**: Python 3.11 based on Debian/Ubuntu with Playwright dependencies (`mcr.microsoft.com/playwright:v1.49.0-jammy`).
* **Autoscaling Triggers**:
  * **HTTP Concurrency Scaling**: Triggers scale-out when active concurrent requests exceed 40 per container instance.
  * **CPU/Memory Scaling**: Scale-out triggered when container CPU utilization exceeds 75%.
* **Crucial Playwright Setting**:
  * Container Apps mount `/dev/shm` (Shared Memory) with **>= 2GB allocation** to support concurrent headless Chromium browser sandboxing without out-of-memory kernel traps.

### 5.2 Database Tier: Azure Database for PostgreSQL Flexible Server
* **Engine**: PostgreSQL 15 or 16.
* **Network Isolation**: Dedicated private subnet via Azure VNet injection (`Microsoft.DBforPostgreSQL/flexibleServers`). Public internet access is permanently disabled.
* **Connection Pooling**: Integrated **PgBouncer** is enabled directly on the Flexible Server instance, handling connection surges up to 1,500 connections.
* **Automated Backups**: Full automated daily backups with point-in-time recovery (PITR) retained for 35 days.
* **Encryption**: Storage encrypted with Azure Storage service encryption (AES-256) by default; Customer-Managed Keys (CMK) via Key Vault supported.

### 5.3 AI Tier: Azure AI Foundry & Azure OpenAI Service
* **Model Deployments**:
  * `gpt-4o` (Version `2024-08-01` or latest): High-reasoning model for specification analysis, edge-case generation, and test code synthesis.
  * `gpt-4.1-nano` or `gpt-4.1-mini`: Ultra-low latency model for high-speed synthetic data synthesis and instant token counts.
* **Network Connectivity**: Integrated into the VNet via **Azure Private Endpoint**. All model traffic travels over Microsoft's global fiber backbone without internet transit.
* **FinOps Governance**: TCS QE Migration Studio features an integrated token accounting ledger that tracks prompt tokens, completion tokens, execution duration, and USD cost per project and scenario.

### 5.4 Edge & Ingress: Azure Application Gateway v2 (WAF)
* **SSL/TLS Termination**: Enforces TLS 1.3 encryption. SSL certificates managed via Azure Key Vault integration with automated rotation.
* **Web Application Firewall (WAF)**: Runs OWASP Core Rule Set (CRS 3.2) in `Prevention` mode to protect against SQLi, XSS, and HTTP protocol anomalies.
* **URL Routing Configuration**:
  * Path `/*` $\rightarrow$ Routes to Frontend Container App (port 3000).
  * Path `/api/*` $\rightarrow$ Routes to Backend API Container App (port 8000).

### 5.5 Secrets & Encryption: Azure Key Vault
* Zero credentials or API keys stored in source code or container images.
* The Container Apps utilize **Azure User-Assigned Managed Identity** to retrieve:
  * Database connection strings.
  * Azure OpenAI keys (or token-based Entra ID authentication).
  * Workato API client credentials.
  * Tricentis Tosca DEX & Test Data Service (TDS) API credentials.
  * Tricentis qTest Manager Bearer authentication tokens.

---

## 6. Enterprise Security, Privacy & Compliance (InfoSec Matrix)

> [!IMPORTANT]
> The following responses address standard corporate InfoSec and Risk Compliance assessment criteria:

| Security Domain | Client Requirement | TCS QE Migration Studio on Azure Implementation |
| :--- | :--- | :--- |
| **Model Data Privacy** | Client proprietary data must not train public AI models. | **Guaranteed Zero Data Retention (ZDR)** via Azure OpenAI enterprise licensing. Prompts, documents, and completions are never utilized for model training. |
| **Data in Transit** | All communication channels must be encrypted. | Enforced **TLS 1.3** across Application Gateway, container-to-container calls, and database connections. |
| **Data at Rest** | Relational databases and object stores must be encrypted. | **FIPS 140-2 validated AES-256 bit encryption** on PostgreSQL Flexible Server and Azure Blob Storage. |
| **Network Isolation** | Backend must have no public internet routable IP addresses. | All backend compute, databases, and AI endpoints reside in private subnets accessed strictly via **Private Endpoints (Private Link)**. |
| **Identity & Access** | Integration with corporate identity management. | Native **Microsoft Entra ID (Azure AD)** Single Sign-On (SSO) using OpenID Connect (OIDC) and SAML 2.0 with MFA enforcement. |
| **Auditing & Logging** | Complete audit trail of system activities and spending. | All agent executions, token usage, and user actions logged to **Azure Log Analytics** with built-in FinOps ledger reporting. |
| **Toolchain Integration** | Secure bidirectional integration with Tricentis Tosca & qTest. | REST API integration with token encryption via Azure Key Vault, TLS 1.3 transit, and zero-privilege execution agent dispatch. |
| **Vulnerability Mgmt** | Container images must be scanned and certified. | Continuous vulnerability scanning via **Microsoft Defender for Containers** in Azure Container Registry (ACR). |

---

## 7. Operational Cost Model (OpEx Estimates)

*The financial model below represents standard Microsoft Azure commercial pricing (East US / West Europe regions) for **Profile B: Enterprise Standard**:*

| Service Component | Azure Resource Specification | Estimated Monthly Cost (USD) |
| :--- | :--- | :--- |
| **Web & API Compute** | Azure Container Apps (2 FE + 3 BE replicas with auto-scaling) | $140 – $220 |
| **Managed Relational DB**| Azure Database for PostgreSQL Flexible Server (D4ds_v5, HA, 256GB) | $280 – $340 |
| **Edge & Ingress Security**| Azure Application Gateway v2 with WAF | $190 – $260 |
| **Artifact & Document Storage**| Azure Blob Storage (Standard Hot Tier, ~500 GB) | $15 – $25 |
| **Secrets & Encryption** | Azure Key Vault + Hardware Security Modules | $10 – $25 |
| **Monitoring & Telemetry**| Azure Monitor & Log Analytics (~10 GB ingestion/month) | $30 – $55 |
| **Azure OpenAI Consumption**| Pay-as-you-go based on ~10M tokens processed / month | $80 – $180 |
| **TOTAL ESTIMATED CLOUD OPEX**| **Complete Enterprise Footprint** | **~$745 – $1,105 / month** |

---

## 8. Client Prerequisite Checklist (Onboarding Readiness)

To initiate deployment in the client’s Azure tenant, the client cloud team provides:

1. **Target Subscription & Resource Group**:
   * E.g., `rg-tcsqemigration-prod-[region]`.
2. **Quota Approvals**:
   * Azure OpenAI access approved for `gpt-4o` with a minimum allocation of **100,000 TPM** in the selected region.
   * Compute quota for 16 vCPUs in the target region.
3. **Identity & DNS Setup**:
   * Entra ID App Registration configured for SSO (Client ID, Client Secret, Tenant ID).
   * Corporate DNS CNAME entry (e.g., `tcsqemigration.clientdomain.com` pointing to Application Gateway Public IP).
   * SSL Certificate (`.pfx` or uploaded to Key Vault).
4. **Service Principal Permissions**:
   * CI/CD deployment service principal with `Contributor` and `User Access Administrator` on the target Resource Group.

---

## 9. Infrastructure as Code (IaC) Delivery

The infrastructure is provisioned through declarative IaC scripts:
* **Bicep / Terraform**: Complete modules for Network VNet, PostgreSQL, Key Vault, Container Apps, and App Gateway provided in the delivery repository.
* **Deployment Time**: Complete environment provisioning takes **less than 25 minutes** from script execution to operational status.
* **CI/CD Automation**: Compatible with GitHub Actions, GitLab CI, and Azure Pipelines for automated continuous deployment.
